export const environment = {
  production: true,
  api: 'https://api.football-data.org/',
  token: '33c19fe74a4b40a6b118469733e033f2',
  lastUri: '',
};
