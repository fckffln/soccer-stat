export interface Area {
  code: string,
  ensignUrl: string,
  name: string,
  id: number,
}
