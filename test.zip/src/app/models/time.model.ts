import {Team} from "./team.model";

export interface Time {
  awayTeam: Team,
  homeTeam: Team,
}
