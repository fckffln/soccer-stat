export interface Season {
  id: number,
  currentMatchDay: number,
  endDate: string,
  startDate: string,
  winner: string,
}
