export type Options = { [key: string]: [value: string, param: 'GET' | 'ROUTE'] };
